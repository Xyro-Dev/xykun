import { z } from 'zod';
import { insertHistorySchema, downloadHistory } from './schema';

export const errorSchemas = {
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  validation: z.object({
    message: z.string(),
  }),
};

// Simplified Gallery Schema for API response
const gallerySchema = z.object({
  id: z.union([z.string(), z.number()]),
  title: z.object({
    english: z.string().optional(),
    japanese: z.string().optional(),
    pretty: z.string().optional(),
  }),
  coverUrl: z.string(),
  tags: z.array(z.string()),
  pageCount: z.number(),
  uploadDate: z.string().optional(), // formatted date
});

export const api = {
  gallery: {
    search: {
      method: 'GET' as const,
      path: '/api/gallery/search' as const,
      input: z.object({
        query: z.string().min(1),
      }),
      responses: {
        200: gallerySchema,
        404: errorSchemas.notFound,
        500: errorSchemas.internal,
      },
    },
    // We don't define 'download' here as an API endpoint because it returns a file stream, 
    // but we can define the history endpoint
  },
  history: {
    list: {
      method: 'GET' as const,
      path: '/api/history' as const,
      responses: {
        200: z.array(z.custom<typeof downloadHistory.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/history' as const,
      input: insertHistorySchema,
      responses: {
        201: z.custom<typeof downloadHistory.$inferSelect>(),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type GalleryResponse = z.infer<typeof gallerySchema>;
