import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const downloadHistory = pgTable("download_history", {
  id: serial("id").primaryKey(),
  galleryId: text("gallery_id").notNull(),
  title: text("title").notNull(),
  coverUrl: text("cover_url"),
  downloadedAt: timestamp("downloaded_at").defaultNow(),
});

export const insertHistorySchema = createInsertSchema(downloadHistory).omit({ 
  id: true, 
  downloadedAt: true 
});

export type HistoryItem = typeof downloadHistory.$inferSelect;
export type InsertHistory = z.infer<typeof insertHistorySchema>;

// Gallery Types
export interface GalleryTag {
  id: number;
  type: string;
  name: string;
  url: string;
  count: number;
}

export interface GalleryImage {
  t: "j" | "p" | "g"; // type: jpg, png, gif
  w: number;
  h: number;
}

export interface Gallery {
  id: number | string;
  media_id: string;
  title: {
    english: string;
    japanese: string;
    pretty: string;
  };
  images: {
    pages: GalleryImage[];
    cover: GalleryImage;
    thumbnail: GalleryImage;
  };
  scanlator: string;
  upload_date: number;
  tags: GalleryTag[];
  num_pages: number;
  num_favorites: number;
}
