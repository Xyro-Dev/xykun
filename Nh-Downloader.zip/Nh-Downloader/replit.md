# replit.md

## Overview

NH Downloader is a full-stack web application for searching, reading, and downloading manga galleries from nhentai. Users can enter a gallery ID or URL, view gallery metadata and cover art, read galleries online in a built-in reader, and download them as ZIP or PDF files. The app also tracks download history in a PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript, bundled with Vite
- **Routing**: Wouter (lightweight client-side router) with two main routes: Home (`/`) and Reader (`/read/:id`)
- **State Management**: TanStack React Query for server state (API fetching, caching, mutations)
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives with Tailwind CSS
- **Styling**: Tailwind CSS with CSS variables for theming (dark anime theme with deep gunmetal & vibrant red). Custom fonts: Outfit (body) and Space Grotesk (display)
- **Animations**: Framer Motion for page transitions and card effects
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend
- **Framework**: Express.js running on Node.js with TypeScript (compiled via tsx in dev, esbuild for production)
- **HTTP Server**: Node `http.createServer` wrapping Express
- **Development**: Vite dev server middleware served through Express with HMR support
- **Production**: Static files served from `dist/public` with SPA fallback to `index.html`
- **Build**: Custom build script (`script/build.ts`) that runs Vite for client and esbuild for server, outputting to `dist/`

### API Endpoints
- `GET /api/search?q=<id_or_url>` — Fetches gallery metadata from nhentai API (with cheerio scraping fallback)
- `GET /api/download/:id?format=zip|pdf` — Downloads gallery as ZIP or PDF (using archiver and PDFKit)
- `GET /api/history` — Returns recent download history (last 20 entries)
- `POST /api/history` — Records a new download history entry

### Data Layer
- **Database**: PostgreSQL (required via `DATABASE_URL` environment variable)
- **ORM**: Drizzle ORM with `drizzle-zod` for schema validation
- **Schema**: Single table `download_history` with fields: id (serial), galleryId (text), title (text), coverUrl (text), downloadedAt (timestamp)
- **Migrations**: Drizzle Kit with `drizzle-kit push` for schema sync
- **Storage Pattern**: `IStorage` interface implemented by `DatabaseStorage` class in `server/storage.ts`

### Shared Code
- `shared/schema.ts` — Drizzle table definitions, Zod insert schemas, and TypeScript types for galleries
- `shared/routes.ts` — API route definitions with Zod schemas for request/response validation

### Key Design Decisions
1. **Monorepo structure** with client/server/shared directories — keeps frontend, backend, and shared types in one repo for easy development
2. **Proxy pattern for external API** — Server-side fetching from nhentai avoids CORS issues and allows image proxying for downloads
3. **Dual download formats** — ZIP (via archiver) and PDF (via PDFKit with sharp for image processing) give users flexibility
4. **Cheerio fallback** — If the nhentai JSON API fails, the server scrapes the HTML page as a fallback

## External Dependencies

### Database
- **PostgreSQL** — Required. Connection via `DATABASE_URL` environment variable. Used with `pg` (node-postgres) Pool

### External APIs
- **nhentai.net** — Gallery data fetched from `https://nhentai.net/api/gallery/:id` and images from `https://i.nhentai.net/galleries/`. No API key required, uses User-Agent spoofing

### Key npm Packages
- **Server**: express, drizzle-orm, pg, axios, cheerio, archiver, pdfkit, sharp, zod
- **Client**: react, wouter, @tanstack/react-query, framer-motion, tailwindcss, shadcn/ui (Radix primitives), lucide-react
- **Build**: vite, esbuild (via script/build.ts), tsx (TypeScript execution)
- **Replit-specific**: @replit/vite-plugin-runtime-error-modal, @replit/vite-plugin-cartographer, @replit/vite-plugin-dev-banner