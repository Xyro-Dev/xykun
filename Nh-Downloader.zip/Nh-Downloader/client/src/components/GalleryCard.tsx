import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, BookOpen, Clock, FileText } from "lucide-react";
import type { GalleryResponse } from "@shared/routes";
import { useAddToHistory } from "@/hooks/use-gallery";
import { useLocation } from "wouter";

interface GalleryCardProps {
  gallery: GalleryResponse;
}

export function GalleryCard({ gallery }: GalleryCardProps) {
  const [, setLocation] = useLocation();
  const addToHistory = useAddToHistory();

  const handleDownload = () => {
    // 1. Add to history
    addToHistory.mutate({
      galleryId: String(gallery.id),
      title: gallery.title.pretty || gallery.title.english || "Unknown Title",
      coverUrl: gallery.coverUrl,
    });

    // 2. Trigger download
    window.location.href = `/api/download/${gallery.id}`;
  };

  const handleRead = () => {
    setLocation(`/read/${gallery.id}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className="glass-card overflow-hidden border-border/50 bg-card/60 hover:border-primary/30 transition-colors duration-300">
        <div className="flex flex-col md:flex-row gap-6 p-6">
          {/* Cover Image */}
          <div className="w-full md:w-48 lg:w-56 shrink-0">
            <div className="aspect-[2/3] rounded-xl overflow-hidden shadow-2xl shadow-black/40 ring-1 ring-white/10 relative group">
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <img
                src={gallery.coverUrl}
                alt={gallery.title.pretty || "Cover"}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 flex flex-col">
            <div className="mb-4">
              <h2 className="text-2xl md:text-3xl font-display font-bold text-foreground leading-tight mb-2">
                {gallery.title.pretty || gallery.title.english}
              </h2>
              {gallery.title.japanese && (
                <p className="text-muted-foreground font-sans text-sm opacity-80 mb-4">
                  {gallery.title.japanese}
                </p>
              )}
              
              <div className="flex flex-wrap gap-2 mb-6">
                {gallery.tags.slice(0, 8).map((tag) => (
                  <Badge 
                    key={tag} 
                    variant="secondary" 
                    className="bg-secondary/80 hover:bg-primary/20 hover:text-primary transition-colors cursor-default"
                  >
                    {tag}
                  </Badge>
                ))}
                {gallery.tags.length > 8 && (
                  <Badge variant="outline" className="opacity-60">+{gallery.tags.length - 8} more</Badge>
                )}
              </div>
            </div>

            <div className="mt-auto space-y-6">
              <div className="flex items-center gap-6 text-sm text-muted-foreground font-medium">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" />
                  <span>{gallery.pageCount} Pages</span>
                </div>
                {gallery.uploadDate && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-primary" />
                    <span>{gallery.uploadDate}</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-3">
                <Button 
                  size="lg" 
                  onClick={handleDownload}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 font-semibold px-8"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download ZIP
                </Button>
                
                <Button 
                  size="lg" 
                  variant="outline" 
                  onClick={handleRead}
                  className="border-primary/30 text-primary hover:bg-primary/10 hover:border-primary font-semibold px-8"
                >
                  <BookOpen className="mr-2 h-5 w-5" />
                  Read Online
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
