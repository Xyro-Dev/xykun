import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertHistory } from "@shared/schema";

// Search Gallery
export function useGallerySearch(query: string) {
  return useQuery({
    queryKey: [api.gallery.search.path, query],
    queryFn: async () => {
      // Prevent fetching on empty query to avoid 404s/errors
      if (!query) return null;
      
      const url = `${api.gallery.search.path}?query=${encodeURIComponent(query)}`;
      const res = await fetch(url, { credentials: "include" });
      
      if (!res.ok) {
        if (res.status === 404) throw new Error("Gallery not found");
        throw new Error("Failed to search gallery");
      }
      
      return api.gallery.search.responses[200].parse(await res.json());
    },
    enabled: query.length > 0,
    retry: false,
  });
}

// History - List
export function useHistory() {
  return useQuery({
    queryKey: [api.history.list.path],
    queryFn: async () => {
      const res = await fetch(api.history.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.history.list.responses[200].parse(await res.json());
    },
  });
}

// History - Add
export function useAddToHistory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertHistory) => {
      const res = await fetch(api.history.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to add to history");
      return api.history.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.history.list.path] });
    },
  });
}
