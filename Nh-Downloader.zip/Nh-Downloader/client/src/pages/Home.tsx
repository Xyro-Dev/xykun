import { useState } from "react";
import { useGallerySearch, useHistory } from "@/hooks/use-gallery";
import { GalleryCard } from "@/components/GalleryCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, History as HistoryIcon, Zap, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function Home() {
  const [searchInput, setSearchInput] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  
  const { data: gallery, isLoading, error } = useGallerySearch(activeQuery);
  const { data: history } = useHistory();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setActiveQuery(searchInput.trim());
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Hero Section */}
      <div className="relative pt-24 pb-16 px-4 md:pt-32 md:pb-24 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-primary/20 blur-[120px] rounded-full pointer-events-none -z-10 opacity-50" />
        
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-wider mb-6">
              <Zap className="w-3 h-3 fill-current" />
              Fast & Anonymous
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold tracking-tight text-white mb-4">
              NH <span className="text-primary">Downloader</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              The premium way to archive and read your favorite galleries.
              Just paste the ID or URL and we'll handle the rest.
            </p>
          </motion.div>

          <motion.form 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            onSubmit={handleSearch}
            className="flex flex-col sm:flex-row gap-3 max-w-xl mx-auto mt-10 relative z-10"
          >
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Enter Gallery ID (e.g. 177013) or URL..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="anime-input pl-12 h-14 text-lg rounded-xl w-full"
              />
            </div>
            <Button 
              type="submit" 
              size="lg" 
              className="h-14 px-8 text-lg font-semibold rounded-xl bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25"
              disabled={isLoading || !searchInput.trim()}
            >
              {isLoading ? "Searching..." : "Fetch"}
            </Button>
          </motion.form>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <div className="flex gap-6">
                <Skeleton className="w-48 h-72 rounded-xl bg-secondary/50" />
                <div className="flex-1 space-y-4">
                  <Skeleton className="h-10 w-3/4 bg-secondary/50" />
                  <Skeleton className="h-4 w-1/2 bg-secondary/50" />
                  <div className="flex gap-2 pt-4">
                    <Skeleton className="h-8 w-20 bg-secondary/50 rounded-full" />
                    <Skeleton className="h-8 w-24 bg-secondary/50 rounded-full" />
                    <Skeleton className="h-8 w-16 bg-secondary/50 rounded-full" />
                  </div>
                </div>
              </div>
            </motion.div>
          ) : error ? (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-16 text-center"
            >
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8 text-destructive" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Not Found</h3>
              <p className="text-muted-foreground max-w-md">
                We couldn't find a gallery with that ID. Please double check your input and try again.
              </p>
            </motion.div>
          ) : gallery ? (
            <div className="mb-20">
              <GalleryCard gallery={gallery} />
            </div>
          ) : null}
        </AnimatePresence>

        {/* History Section */}
        {history && history.length > 0 && (
          <motion.section 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-16"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-secondary rounded-lg">
                <HistoryIcon className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-2xl font-display font-bold">Recent Downloads</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {history.map((item) => (
                <Link key={item.id} href={`/read/${item.galleryId}`} className="group block">
                  <Card className="glass-card overflow-hidden hover:-translate-y-1 transition-transform duration-300">
                    <div className="flex items-start gap-4 p-4">
                      {item.coverUrl ? (
                        <div className="w-20 aspect-[2/3] rounded-md overflow-hidden bg-black/20 shrink-0">
                          <img 
                            src={item.coverUrl} 
                            alt={item.title}
                            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                          />
                        </div>
                      ) : (
                        <div className="w-20 aspect-[2/3] rounded-md bg-secondary flex items-center justify-center shrink-0">
                          <BookOpen className="w-6 h-6 text-muted-foreground" />
                        </div>
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-foreground truncate group-hover:text-primary transition-colors">
                          {item.title}
                        </h4>
                        <p className="text-sm text-muted-foreground mt-1 font-mono">
                          #{item.galleryId}
                        </p>
                        <p className="text-xs text-muted-foreground/60 mt-4">
                          Downloaded {new Date(item.downloadedAt!).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </motion.section>
        )}
      </div>
    </div>
  );
}
