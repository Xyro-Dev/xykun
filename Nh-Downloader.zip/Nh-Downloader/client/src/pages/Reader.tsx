import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Download, AlertCircle, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

export default function Reader() {
  const [match, params] = useRoute("/read/:id");
  const galleryId = params?.id;

  const { data: gallery, isLoading, error } = useQuery({
    queryKey: [api.gallery.search.path, galleryId],
    queryFn: async () => {
      if (!galleryId) return null;
      const url = `${api.gallery.search.path}?query=${encodeURIComponent(galleryId)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch gallery");
      return api.gallery.search.responses[200].parse(await res.json());
    },
    enabled: !!galleryId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto" />
          <p className="text-muted-foreground font-medium animate-pulse">Loading gallery...</p>
        </div>
      </div>
    );
  }

  if (error || !gallery) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-card p-8 rounded-2xl border border-border text-center">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">Error Loading Gallery</h2>
          <p className="text-muted-foreground mb-6">Unable to load this gallery. It may have been removed or the ID is invalid.</p>
          <Link href="/">
            <Button className="w-full">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black/95">
      {/* Header */}
      <header className="fixed top-0 inset-x-0 z-50 h-16 bg-background/80 backdrop-blur-xl border-b border-white/5 flex items-center justify-between px-4 lg:px-8">
        <div className="flex items-center gap-4 flex-1 min-w-0">
          <Link href="/">
            <Button variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-foreground">
              <ChevronLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="truncate">
            <h1 className="font-bold text-sm md:text-base truncate">
              {gallery.title.pretty || gallery.title.english}
            </h1>
            <p className="text-xs text-muted-foreground truncate font-mono">
              {gallery.pageCount} Pages • {gallery.id}
            </p>
          </div>
        </div>

        <Button 
          size="sm" 
          onClick={() => window.location.href = `/api/download/${gallery.id}`}
          className="ml-4 shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          <Download className="w-4 h-4 mr-2 hidden sm:block" />
          Download
        </Button>
      </header>

      {/* Reader Content */}
      <main className="pt-24 pb-20 max-w-4xl mx-auto px-4 md:px-0">
        <div className="space-y-4">
          {Array.from({ length: gallery.pageCount }).map((_, i) => (
            <div key={i} className="relative w-full bg-zinc-900 rounded-lg overflow-hidden min-h-[400px]">
              {/* Note: The backend would need a proxy endpoint like /api/proxy/image/:id/:page to avoid CORS */}
              {/* Since we don't have the proxy endpoint defined in schema, we will assume a pattern or use placeholder */}
              {/* In a real app, use <img src={`/api/proxy/image/${gallery.id}/${i + 1}`} /> */}
              
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground z-0">
                <p className="font-mono text-sm opacity-50">Page {i + 1}</p>
              </div>

              {/* Using a hypothetical proxy path. In a real impl, this needs the backend proxy route. */}
              {/* For this demo, we'll simulate the image slot styling */}
              <img
                loading="lazy"
                src={`/api/proxy/image/${gallery.id}/${i + 1}`}
                alt={`Page ${i + 1}`}
                className="relative z-10 w-full h-auto block"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center py-10 border-t border-white/10">
          <p className="text-muted-foreground mb-6">You've reached the end</p>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline" size="lg">Read Another</Button>
            </Link>
            <Button size="lg" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              Back to Top
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
