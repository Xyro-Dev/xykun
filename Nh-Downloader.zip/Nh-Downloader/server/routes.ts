import type { Express } from "express";
import type { Server } from "http";
import axios from "axios";
import archiver from "archiver";
import PDFDocument from "pdfkit";
import sharp from "sharp";
import * as cheerio from "cheerio";
import FormData from "form-data";
import fileType from "file-type";

/* ================= CONFIG ================= */

const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";

const ENABLE_TRANSLATE = true;
const TRANSLATE_CONCURRENCY = 5;

const TRANSLATE_CONFIG = {
  api: "https://imagetranslate.ai/api/image/translate",
  recordId: "202601031636402jI2",
  target: "id",
};

/* ================= UTIL ================= */

function extractId(input: string): string | null {
  const urlMatch = input.match(/\/g\/(\d+)/);
  if (urlMatch) return urlMatch[1];
  const idMatch = input.match(/^\d+$/);
  if (idMatch) return idMatch[0];
  return null;
}

function getExt(t: string) {
  return t === "j" ? "jpg" : t === "p" ? "png" : "gif";
}

function randomImageServer() {
  return `i${Math.floor(Math.random() * 9) + 1}`;
}

function getRandomIP() {
  return Array.from({ length: 4 }, () =>
    Math.floor(Math.random() * 256)
  ).join(".");
}

/* ================= FETCH GALLERY ================= */

async function fetchGalleryData(id: string) {
  try {
    const response = await axios.get(
      `https://nhentai.net/api/gallery/${id}`,
      { headers: { "User-Agent": USER_AGENT } }
    );
    return response.data;
  } catch {
    const res = await axios.get(
      `https://nhentai.net/g/${id}/`,
      { headers: { "User-Agent": USER_AGENT } }
    );
    const $ = cheerio.load(res.data);
    const script = $("#root-next-state").html();
    if (script) return JSON.parse(script).gallery;
    throw new Error("Gallery not found");
  }
}

/* ================= TRANSLATOR ================= */

async function translateImage(imageUrl: string): Promise<Buffer | null> {
  try {
    const res = await axios.post(
      TRANSLATE_CONFIG.api,
      {
        imageUrl,
        sourceLanguage: "auto",
        targetLanguage: TRANSLATE_CONFIG.target,
        mode: "manga",
        translator: "grok-4-fast",
      },
      {
        headers: {
          "Content-Type": "application/json",
          "x-record-id": TRANSLATE_CONFIG.recordId,
          "User-Agent": "Mozilla/5.0",
          Referer: "https://imagetranslate.ai/manga-translator",
          "X-Forwarded-For": getRandomIP(),
        },
        timeout: 60000,
      }
    );

    if (!res.data?.success) return null;

    const base64 = res.data.translatedImageUrl.split(",")[1];
    return Buffer.from(base64, "base64");
  } catch {
    return null;
  }
}

async function bulkTranslateImages(urls: string[]) {
  const results: (Buffer | null)[] = new Array(urls.length);
  let pointer = 0;

  async function worker() {
    while (true) {
      const index = pointer++;
      if (index >= urls.length) break;
      results[index] = await translateImage(urls[index]);
    }
  }

  const workers = Array.from(
    { length: TRANSLATE_CONCURRENCY },
    worker
  );

  await Promise.all(workers);
  return results;
}

/* ================= UPLOAD ================= */

async function uploadToQuax(buffer: Buffer) {
  const ext = (await fileType.fromBuffer(buffer))?.ext || "pdf";

  const form = new FormData();
  form.append("files[]", buffer, `result.${ext}`);

  const res = await axios.post(
    "https://qu.ax/upload.php",
    form,
    {
      headers: {
        ...form.getHeaders(),
        Origin: "https://qu.ax",
        Referer: "https://qu.ax/",
        "User-Agent": "Mozilla/5.0",
      },
    }
  );

  if (!res.data?.success) {
    return { status: false, msg: "Upload gagal" };
  }

  return { status: true, url: res.data.files[0].url };
}

/* ================= ROUTES ================= */

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  /* ========= SEARCH ========= */
  app.get("/api/search", async (req, res) => {
    const id = extractId(String(req.query.q || ""));
    if (!id) return res.status(400).json({ error: "Invalid ID" });

    try {
      const data = await fetchGalleryData(id);
      const mediaId = data.media_id;

      const images = data.images.pages.map((p: any, i: number) => {
        const server = randomImageServer();
        return `https://${server}.nhentai.net/galleries/${mediaId}/${i + 1}.${getExt(p.t)}`;
      });

      res.json({
        id: data.id,
        title: data.title.pretty || data.title.english,
        pages: data.num_pages,
        preview: images[0], // 🔥 ambil pertama
        images,
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  /* ========= DOWNLOAD ========= */
  app.get("/api/download/pdf/:id", async (req, res) => {
    const { id } = req.params;

    try {
      const data = await fetchGalleryData(id);

      const images = data.images.pages.map((p: any, i: number) => {
        const server = randomImageServer();
        return `https://${server}.nhentai.net/galleries/${data.media_id}/${i + 1}.${getExt(p.t)}`;
      });

      let imageBuffers: (Buffer | null)[];

      if (ENABLE_TRANSLATE) {
        imageBuffers = await bulkTranslateImages(images);
      } else {
        imageBuffers = await Promise.all(
          images.map(async (url) => {
            const { data } = await axios.get(url, {
              responseType: "arraybuffer",
              headers: {
                "User-Agent": USER_AGENT,
                Referer: "https://nhentai.net/",
              },
            });
            return Buffer.from(data);
          })
        );
      }

      const doc = new PDFDocument({ autoFirstPage: false });
      const chunks: Buffer[] = [];

      doc.on("data", (d) => chunks.push(d));

      for (const raw of imageBuffers) {
        if (!raw) continue;

        const buffer = await sharp(raw)
          .resize({ width: 1600, withoutEnlargement: true })
          .jpeg({ quality: 85 })
          .toBuffer();

        const meta = await sharp(buffer).metadata();

        doc.addPage({
          size: [meta.width || 800, meta.height || 1200],
        });

        doc.image(buffer, 0, 0, {
          width: meta.width,
          height: meta.height,
        });
      }

      doc.end();

      const pdfBuffer: Buffer = await new Promise((resolve) =>
        doc.on("end", () => resolve(Buffer.concat(chunks)))
      );

      const uploadResult = await uploadToQuax(pdfBuffer);

      return res.json(uploadResult);

    } catch (e: any) {
      res.status(500).json({ status: false, msg: e.message });
    }
  });

  return httpServer;
}