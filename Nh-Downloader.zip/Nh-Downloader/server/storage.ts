import { downloadHistory, type HistoryItem, type InsertHistory } from "@shared/schema";
import { db } from "./db";
import { desc } from "drizzle-orm";

export interface IStorage {
  getHistory(): Promise<HistoryItem[]>;
  createHistory(item: InsertHistory): Promise<HistoryItem>;
}

export class DatabaseStorage implements IStorage {
  async getHistory(): Promise<HistoryItem[]> {
    return await db.select()
      .from(downloadHistory)
      .orderBy(desc(downloadHistory.downloadedAt))
      .limit(20);
  }

  async createHistory(item: InsertHistory): Promise<HistoryItem> {
    const [created] = await db.insert(downloadHistory)
      .values(item)
      .returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
